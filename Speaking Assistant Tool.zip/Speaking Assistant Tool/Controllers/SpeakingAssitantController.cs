﻿using Microsoft.AspNetCore.Mvc;

namespace TeamBingo.Controllers
{
    public class SpeakingAssitantController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
