﻿using DocumentFormat.OpenXml.Packaging;
using DocumentFormat.OpenXml.Wordprocessing;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Hosting.Internal;
using OpenAI.Completions;
using Standard.AI.OpenAI.Models.Services.Foundations.ChatCompletions;
using System.Diagnostics;
using System.Text;
using TeamBingo.API;
using TeamBingo.Models;

namespace TeamBingo.Controllers
{

    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;

        private readonly Microsoft.AspNetCore.Hosting.IHostingEnvironment _hostingEnvironment;
        OpenAIProxy openAIProxy = new OpenAIProxy("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", "org-E8RG3KieB88zwV9Wx92nosp2");

        public HomeController(ILogger<HomeController> logger, Microsoft.AspNetCore.Hosting.IHostingEnvironment hostingEnvironment)
        {
            _logger = logger;
            _hostingEnvironment = hostingEnvironment;
        }

        [HttpGet]
        public List<string> Slide(string prompt="Make it intresting")
        {

            string webRootPath = _hostingEnvironment.WebRootPath;
            string contentRootPath = _hostingEnvironment.ContentRootPath + "\\PPTSource\\";

            var fullpath = Path.Combine(contentRootPath, "Tricentis TOSCA_PresentationFinal.pptx");
            List<string> returnListPPT;

            using (var ppt = PresentationDocument.Open(fullpath, false))
            {
                var sb = new StringBuilder();
                if (prompt.Trim() != string.Empty)
                    sb.Append(prompt + " \n");
                var slides = ppt.PresentationPart.SlideParts;
                var noOfSlides = slides.Count();
                List<string> ret = new List<string>();
                returnListPPT = new List<string>();
                int i = 0;
                foreach (var slide in slides)
                {
                    // if (i == )
                    // {
                    var paragraphs = slide.Slide.Descendants<DocumentFormat.OpenXml.Drawing.Paragraph>();
                    foreach (var paragraph in paragraphs)
                    {
                        sb.Append(paragraph.InnerText);
                        sb.Append(" ");
                    }


                    // }


                    //sb.Clear();
                    //i++;
                }
                returnListPPT.Add(ChatGPT(sb.ToString()));

                return returnListPPT;
            }
        }

        [HttpGet]
        public string ChatGPT(string pptText)
        {
            string ret = "";
            Task<ChatCompletionMessage[]> result = openAIProxy.SendChatMessage(pptText);
            result.Wait();

            if (result.IsCompletedSuccessfully)
                ret = result.Result[0].Content.ToString();

            return ret;
        }
        public IActionResult Index()
        {
            return View();
        }

        public String Text()
        {
            OpenAIProxy openAIProxy = new OpenAIProxy("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", "org-E8RG3KieB88zwV9Wx92nosp2");
            using (var ppt = PresentationDocument.Open(@"C:\Users\ppodduturi\source\repos\TeamBingo\Powerpoint\HR3.pptx", false))
            {
                var sb = new StringBuilder();
                var slides = ppt.PresentationPart.SlideParts;
                foreach (var slide in slides)
                {
                    var paragraphs = slide.Slide.Descendants<DocumentFormat.OpenXml.Drawing.Paragraph>();
                    foreach (var paragraph in paragraphs)
                    {
                        sb.Append(paragraph.InnerText);
                        sb.Append(" ");
                    }

                }
                string pptText = sb.ToString();
                var result = openAIProxy.SendChatMessage(pptText);
                return "ok";

            }
        }

        //  [HttpPost]
        ////public ActionResult UploadFile(HttpPostedFileBase file_uploader)
        ////{
        ////    try
        ////    {
        ////        if (file.ContentLength > 0)
        ////        {
        ////            string _FileName = Path.GetFileName(file.FileName);
        ////            string _path = Path.Combine(Server.MapPath("~/UploadedFiles"), _FileName);
        ////            file.SaveAs(_path);
        ////        }
        ////        ViewBag.Message = "File Uploaded Successfully!!";
        ////        return View();
        ////    }
        ////    catch
        ////    {
        ////        ViewBag.Message = "File upload failed!!";
        ////        return View();
        ////    }
        ////}
        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }



    }
}